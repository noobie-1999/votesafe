<?php
	$domain = 'localhost';
	$username = 'root';
	$password = '';
	$dbname = 'votesafe';

	$conn = mysqli_connect($domain,$username,$password,$dbname);
	